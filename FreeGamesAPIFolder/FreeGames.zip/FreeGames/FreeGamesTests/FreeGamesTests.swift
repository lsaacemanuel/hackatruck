//
//  FreeGamesTests.swift
//  FreeGamesTests
//
//  Created by Turma01-15 on 30/09/24.
//

import Testing
@testable import FreeGames

struct FreeGamesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
