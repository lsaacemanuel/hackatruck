//
//  mapaTests.swift
//  mapaTests
//
//  Created by Turma01-15 on 25/09/24.
//

import Testing
@testable import mapa

struct mapaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
