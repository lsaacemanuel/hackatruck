//
//  mapaApp.swift
//  mapa
//
//  Created by Turma01-15 on 25/09/24.
//

import SwiftUI

@main
struct mapaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
