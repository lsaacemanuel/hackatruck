//
//  Desafio1NStackTests.swift
//  Desafio1NStackTests
//
//  Created by Turma01-15 on 23/09/24.
//

import Testing
@testable import Desafio1NStack

struct Desafio1NStackTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
