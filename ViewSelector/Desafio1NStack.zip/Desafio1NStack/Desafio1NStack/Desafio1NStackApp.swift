//
//  Desafio1NStackApp.swift
//  Desafio1NStack
//
//  Created by Turma01-15 on 23/09/24.
//

import SwiftUI

@main
struct Desafio1NStackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
