//
//  mapaProjetoFinalApp.swift
//  mapaProjetoFinal
//
//  Created by Turma01-15 on 09/10/24.
//

import SwiftUI

@main
struct mapaProjetoFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
