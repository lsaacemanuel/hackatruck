//
//  rotas.swift
//  mapaProjetoFinal
//
//  Created by Turma01-15 on 10/10/24.
//

import SwiftUI

struct rotas: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    rotas()
}
