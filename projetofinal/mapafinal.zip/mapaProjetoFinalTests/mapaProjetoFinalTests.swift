//
//  mapaProjetoFinalTests.swift
//  mapaProjetoFinalTests
//
//  Created by Turma01-15 on 09/10/24.
//

import Testing
@testable import mapaProjetoFinal

struct mapaProjetoFinalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
