//
//  Spotify2Tests.swift
//  Spotify2Tests
//
//  Created by Turma01-15 on 24/09/24.
//

import Testing
@testable import Spotify2

struct Spotify2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
