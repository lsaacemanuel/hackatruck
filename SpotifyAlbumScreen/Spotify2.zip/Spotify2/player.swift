//
//  player.swift
//  Spotify2
//
//  Created by Turma01-15 on 24/09/24.
//

import SwiftUI

struct player: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    player()
}
