//
//  Spotify2App.swift
//  Spotify2
//
//  Created by Turma01-15 on 24/09/24.
//

import SwiftUI

@main
struct Spotify2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
